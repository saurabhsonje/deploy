#!/bin/sh
#Developed By Sandip Anwat for the official purpose only
#This configuration review script is developed according specific needss.
#Last Update Data : 22 Feb, 2020
# Use following command to run this scipit
# cd to Dir location where script is in place. 
# chmod u+x *
# Present_Work_Directory_location/audit.sh
dir_loc="$(pwd)"
>$dir_loc/output
echo " CIS Benchmar Vulnerability check Audit Started"
echo "=================================================================================="
echo "    *************** 1 Initial Setup  *****************"
echo "    *************** 1.1 Filesystem Configuration *****************"
echo " " 
echo "    *************** 1.1.1 Disable unused filesystems *****************"
echo "1.1.1.1 Ensure mounting of cramfs filesystems is disabled (Scored)"
out="$(lsmod | grep cramfs)"
if [ -z "$out" ]; then
        echo "[+]Pass:cramfs filesystems is already disabled"
else
        echo "[-]Error:This vulnerability needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " "
echo "1.1.1.2 Ensure mounting of freevxfs filesystems is disabled (Scored)"
out="$(lsmod | grep freevxfs)"
if [ -z "$out" ]; then
        echo "[+]Pass:freevxfs filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present.Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "1.1.1.3 Ensure mounting of jffs2 filesystems is disabled (Scored)"
out="$(lsmod | grep jffs2)"
if [ -z "$out" ]; then
        echo "[+]Pass:jffs2 filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present.Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "1.1.1.4 Ensure mounting of hfs filesystems is disabled (Scored)"
out="$(lsmod | grep hfs)"
if [ -z "$out" ]; then
        echo "[+]Pass:hfs filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present.Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "1.1.1.5 Ensure mounting of hfsplus filesystems is disabled (Scored)"
out="$(lsmod | grep hfsplus)"
if [ -z "$out" ]; then
        echo "[+]Pass:hfsplus filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present.Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "1.1.1.6 Ensure mounting of squashfs filesystems is disabled (Scored)"
out="$(lsmod | grep squashfs)"
if [ -z "$out" ]; then
        echo "[+]Pass:squashfs filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present. Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " "
echo " " 
echo "1.1.1.7 Ensure mounting of udf filesystems is disabled (Scored)"
out="$(lsmod | grep udf)"
if [ -z "$out" ]; then
        echo "[+]Pass:udf filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present. Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "1.1.1.8 Ensure mounting of FAT filesystems is limited (Not Scored)"
out="$(lsmod | grep vfat)"
if [ -z "$out" ]; then
        echo "[+]Pass:vfat filesystems is already disabled"
else
        echo "[-]Error:Vulnerability is Present. Needs to be fixed. Please  Check section \"1.1 Filesystem Configuration\" in CIS Benchmark"
fi
echo " " 
echo " " 
echo "*************** 1.1.2 Ensure /tmp is configured (Scored) *****************"
mount | grep -E '\s/tmp\s'; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /tmp is already configured"
fi
echo " "
echo " " 
#echo "##################################################################################"
echo "*************** 1.1.3 Ensure nodev option set on /tmp partition (Scored) *****************"
mount | grep -E '\s/tmp\s' | grep -v nodev; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: nodev option is alreadyset on /tmp partition (Scored)"
fi
echo " " 
echo " " 
echo "*************** 1.1.4 Ensure nosuid option set on /tmp partition (Scored) *****************"
mount | grep -E '\s/tmp\s' | grep -v nosuid;out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:nosuid option is already set on /tmp partition (Scored)"
fi
echo " "
echo " "

#echo "##################################################################################"
echo "*************** 1.1.5 Ensure noexec option set on /tmp partition (Scored) *****************"
mount | grep -E '\s/tmp\s' | grep -v noexec;out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:noexec option is already set on /tmp partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.6 Ensure separate partition exists for /var (Scored) *****************"
mount | grep -E '\s/var\s'; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /var is already configured"
fi
echo " "
echo " "
echo "*************** 1.1.7 Ensure separate partition exists for /var/tmp (Scored) *****************"
mount | grep /var/tmp; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /var/tmp is already configured"
fi
echo " "
echo " "
echo "*************** 1.1.8 Ensure nodev option set on /var/tmp partition (Scored) *****************"
mount | grep -E '\s/var/tmp\s' | grep -v nodev; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: nodev option is already set on /var/tmp partition (Scored)"
fi
echo " " 
echo " "
echo "*************** 1.1.9 Ensure nosuid option set on /var/tmp partition (Scored) *****************"
mount | grep -E '\s//var/tmp\s' | grep -v nosuid;out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:nosuid option is already set on /var/tmp partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.10 Ensure noexec option set on /var/tmp partition (Scored) *****************"
mount | grep -E '\s//var/tmp\s' | grep -v noexec;out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:noexec option is already set on /var/tmp partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.11 Ensure separate partition exists for /var/log (Scored) *****************"
mount | grep /var/log; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /var/log is already configured"
fi
echo " "
echo " "
echo "*************** 1.1.12 Ensure separate partition exists for /var/log/audit (Scored) *****************"
mount | grep /var/log/audit; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /var/log/audit is already configured"
fi
echo " "
echo " "
echo "*************** 1.1.13 Ensure separate partition exists for /home (Scored) *****************"
mount | grep /home; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass-Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:Separate /home is already configured"
fi
echo " "
echo " "
echo "*************** 1.1.14 Ensure nodev option set on /home partition (Scored) *****************"
mount | grep -E '\s/home\s' | grep -v nodev; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: nodev option is already set on /home partition (Scored)"
fi
echo " "
echo " "

echo "*************** 1.1.15 Ensure nodev option set on /dev/shm partition (Scored) *****************"
mount | grep -E '\s/dev/shm\s' | grep -i nodev; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: nodev option is already set on /dev/shm partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.16 Ensure nosuid option set on /dev/shm partition (Scored) *****************"
mount | grep -E '\s/dev/shm\s' | grep -i nosuid; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: nosuid option is already set on /dev/shm partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.17 Ensure noexec option set on /dev/shm partition (Scored) *****************"
mount | grep -E '\s/dev/shm\s' | grep -i noexec; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: noexec option is already set on /dev/shm partition (Scored)"
fi
echo " "
echo " "
echo "*************** 1.1.21 Ensure sticky bit is set on all world-writable directories (Scored) *****************"
df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null; out="$(echo $?)";
if [ "$out" == 1 ]; then
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass: sticky bit is already set on all world-writable directories"
fi
echo " "
echo " "
echo "*************** 1.1.22 Disable Automounting (Scored)  *****************"
chkconfig --list | grep -i autofs; out="$(echo $?)"
if [ "$out" == "1" ]; then
	echo "[+]Pass:Automounting is already disabled"
else
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
fi
echo " "
echo " "
echo "*************** 1.1.23 Disable USB Storage (Scored)  *****************"
modprobe -n -v usb-storage; out="$(echo $?)"
if [ "$out" == "1" ]; then
        echo "[+]Pass:USB Storage already disabled"
else
        echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.2 Configure Software Updates *****************"
echo " " 
echo "*************** 1.2.1 Ensure package manager repositories are configured (Not Scored)  *****************"
yum repolist; out="$(echo $?)"
if [ "$out" == "0" ]; then
        echo "[+]Pass:package manager repositories are already configured"
else
        echo "[-]Error:package manager repositories are not  configured"
fi
echo " "
echo " "
echo "*************** 1.2.2 Ensure GPG keys are configured (Not Scored)  *****************"
out="$(rpm -q gpg-pubkey --qf '%{name}-%{version}-%{release} --> %{summary}\n')"
if [ "$out" == "package gpg-pubkey is not installed" ]; then
	 echo "[-]Error: GPG keys are not configured (Not Scored)"
else
        echo "[+]Pass: GPG keys are already configured (Not Scored)"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.3 Filesystem Integrity Checking  *****************"
echo " " 
echo "*************** 1.3.1 Ensure AIDE is installed (Scored)  *****************"
out="$(rpm -q aide)"
if [ "$out" == "package aide is not installed" ]; then
 	echo "[-]Error: Package AIDE is not installed (Scored)."
	echo "Installing the Package..................."
        yum -y install aide
	aide --init
        echo "[+]Pass: Configured AIDE as appropriate for your environment."

else
        echo "[+]Pass: Package AIDE is already installed (Scored)"
fi
echo " " 
echo " "
echo "*************** 1.3.2  Ensure filesystem integrity is regularly checked (Scored)  *****************"
out="$(crontab -u root -l | grep aide)"
if [[ $out = *"aide"* ]]; then
        echo "[+]Pass:filesystem integrity is regularly checkek"
else
        echo "[-]Error:filesystem integrity is not regularly checked."
	echo "setting up file system integrity......................"
        
        (crontab -l 2>/dev/null; echo "0 5 * * * /usr/sbin/aide --check") | crontab -
        crontab -l
        echo "[+]Done"
       

fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.4 Secure Boot Settings  *****************"
echo " " 
echo "*************** 1.4.1 Ensure permissions on bootloader config are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /boot/grub/grub.conf)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass:permissions on bootloader config are already configured (Scored)"
else
        echo "[-]Error:permissions on bootloader config are not configured (Scored). To configured it, Please check section 1.4.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.4.2 Ensure bootloader password is set (Scored)  *****************"

out="$(grep "^\s*password" /boot/grub/menu.lst)"
if [ -z "$out" ]; then
  	echo "[-]Partially Pass:Priority:LOW-We Can take Exception for this Vulnerability"

else
        echo "[+]Pass:bootloader password is already set (Scored)"
fi
echo " "
echo " "
echo "*************** 1.4.3 Ensure authentication required for single user mode (Scored)   *****************"
out="$(grep ^root:[*\!]: /etc/shadow)"
if [ -z "$out" ]; then
 	 echo "[+]Pass:authentication required for single user mode is already set (Scored)"
else
        echo "[-]Error:authentication required for single user mode is not set (Scored).To set it ?,  Please check section 1.4.3 in CIS Benchmark"
fi
echo " "
echo " " 
echo "*************** 1.4.4 Ensure interactive boot is not enabled (Not Scored)   *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " " 
echo " "
echo "=================================================================================="
echo "    *************** 1.5 Additional Process Hardening  *****************"
echo " "
echo "*************** 1.5.1 Ensure core dumps are restricted (Scored)  *****************"
out="$(sysctl fs.suid_dumpable)";
if [[ $out = "fs.suid_dumpable = 0" ]]; then
        echo "[+]Pass:core dumps are already restricted (Scored)"
else
        echo "[-]Error:core dumps are not restricted (Scored). To configured it, Please check section 1.5.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.5.2 Ensure XD/NX support is enabled (Scored)   *****************"
out="$([[ -n $(grep noexec[0-9]*=off /proc/cmdline) || -z $(grep -E -i ' (pae|nx) ' /proc/cpuinfo) || -n $(grep '\sNX\s.*\sprotection:\s' /var/log/dmesg | grep -v active) ]] && echo "NX Protection is not active")"
if [ -z "$out" ]; then
         echo "[+]Pass:XD/NX support is already enabled (Scored)"
else
        echo "[-]Error:XD/NX support is not enabled (Scored).To set it ?,  Please check section 1.5.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.5.3 Ensure address space layout randomization (ASLR) is enabled (Scored)  *****************"
out="$(sysctl kernel.randomize_va_space)";
if [[ $out = "kernel.randomize_va_space = 2" ]]; then
        echo "[+]Pass:address space layout randomization (ASLR) is already enabled (Scored)"
else
        echo "[-]Error:address space layout randomization (ASLR) is not enabled (Scored). To configured it, Please check section 1.5.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.5.4 Ensure prelink is disabled (Scored)   *****************"
out="$(rpm -qa prelink)"
if [ -z "$out" ]; then
         echo "[+]Pass: prelink is already disabled (Scored)"
else
        echo "[-]Error: prelink is not disabled (Scored).To diabled it,  Please check section 1.5.4 in CIS Benchmark"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.6 Mandatory Access Control  *****************"
echo " "
echo "*************** 1.6.1 Ensure Mandatory Access Control Software is Installed  *****************"
echo "Not all Linux Distributions include Mandatory Access Control software in the base install."
echo " " 
echo "*************** 1.6.1.1 Ensure SELinux or AppArmor are installed (Scored)  *****************"
out="$(rpm -qa libselinux)"
if [[ $out = *"libselinux"* ]]; then
         echo "[+]Pass: SELinux or AppArmor are already installed (Scored)"
else
        echo "[-]Error: SELinux or AppArmor are not  installed. To installed  it,  Please check section 1.6.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.6.2 Configure SELinux  *****************"
echo "*************** 1.6.2.1 Ensure SELinux is not disabled in bootloader configuration (Scored)  *****************"
out="$(grep -oh "\w*selinux=\w*"  /boot/grub/menu.lst)"
if [[ $out = "selinux=0" ]]; then
	echo "[-]Partially Pass-We Can take Exception for this Vulnerability"
else 
	echo "[+]Pass:SELinux is already disabled in bootloader configuration (Scored)"
fi 
echo " " 
echo " " 
echo "*************** 1.6.2.2 Ensure the SELinux state is enforcing (Scored)  *****************"
out="$(sestatus | cut -d " " -f 19)";
if [[ $out = "disabled" ]]; then
        echo "[-]Partially Pass-We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:the SELinux state is already  enforcing (Scored)"
fi
echo " "
echo " "
echo "*************** 1.6.2.3 Ensure SELinux policy is configured (Scored)  *****************"
out="$(sestatus | cut -d " " -f 19)";
if [[ $out = "targeted" ]]; then
        echo "[+]Pass:the SELinux policy is already  enforcing (Scored)"
else
	echo "[-]Partially Pass-We Can take Exception for this Vulnerability"
fi
echo " "
echo " "
echo "*************** 1.6.2.4 Ensure SETroubleshoot is not installed (Scored)  *****************"
out="$(rpm -q setroubleshoot)";
if [[ $out = "package setroubleshoot is not installed" ]]; then
        echo "[+]Pass:SETroubleshoot is not installed (Scored)"
else
        echo "[-]Error:SETroubleshoot is  installed (Scored). To uninstall  it, Please check section 1.6.2.4 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.6.2.5 Ensure the MCS Translation Service (mcstrans) is not installed (Scored)  *****************"
out="$(rpm -q mcstrans)";
if [[ $out = "package mcstrans is not installed" ]]; then
        echo "[+]Pass:MCS Translation Service (mcstrans) is not installed (Scored)"
else
        echo "[-]Error:MCS Translation Service (mcstrans) is  installed (Scored). To uninstall  it, Please check section 1.6.2.5 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.6.2.6 Ensure no unconfined daemons exist (Scored)  *****************"
out="$(ps -eZ | grep -E "initrc" | grep -E -v -w "tr|ps|grep|bash|awk" | tr ':' ' ' | awk '{ print $NF }')"
if [ -z "$out" ]; then
        echo "[+]Pass:no unconfined daemons exist (Scored)"
else
        echo "[-]Error: unconfined daemons exist (Scored).To fix it,  Please  Check section 1.6.2.6 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 1.6.3 Configure AppArmor  *****************"
echo "*************** 1.6.3.1 Ensure AppArmor is not disabled in bootloader configuration (Scored)  *****************"
out="$(grep -oh "\w*apparmor=\w*"  /boot/grub/menu.lst)"
if [[ $out = "apparmor=0" ]]; then
        echo "[-]Error: AppArmor is not disabled in bootloader configuration (Scored). To configure  it,  Please check section 1.6.3.1 in CIS Benchmark"
else
        echo "[+]Pass:AppArmor is already disabled in bootloader configuration (Scored)"
fi
echo " "
echo " "
echo "*************** 1.6.3.2 Ensure all AppArmor Profiles are enforcing (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.7 Warning Banners *****************"
echo " "
echo "*************** 1.7.1 Command Line Warning Banners  *****************"
echo "*************** 1.7.1.1 Ensure message of the day is configured properly (Scored)  *****************"
out="$(cat /etc/motd)"
if [ -z "$out" ]; then
        echo "[-]Error:message of the day is not configured properly (Scored). To Configured it, Please check section 1.7.1.1 in CIS Benchmark "
else
        echo "[+]Pass:message of the day is already configured properly (Scored))"
fi
echo " "
echo " "
echo "*************** 1.7.1.2 Ensure local login warning banner is configured properly (Scored)  *****************"
out="$(grep -o release /etc/issue)"
if [ "$out" != "release"  ]; then
        echo "[+]Pass:local login warning banner is already configured properly (Scored) "
else
        echo "[-]Error:local login warning banner is not configured properly (Scored)"
	echo "Configuring Local Login Banner..........."
        echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue
	echo "[+] Done"
fi
echo " "
echo " "
echo "*************** 1.7.1.3 Ensure remote login warning banner is configured properly (Scored)  *****************"
out="$(grep -o release /etc/issue.net)"
if [ "$out" != "release"  ]; then
        echo "[+]Pass:Remote login warning banner is already configured properly (Scored) "
else
        echo "[-]Error:remote login warning banner is not configured properly (Scored)"
        echo "Configuring Remote Login Banner..........."
        echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue.net
        echo "[+] Done"
fi
echo " "
echo " "

echo " "
echo " "

echo "*************** 1.7.1.4 Ensure permissions on /etc/motd are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/motd)"
if [[ $out = "644 0 0" ]]; then        
	echo "[+]Pass:permissions on /etc/motd are already configured (Scored)"
else
	echo "[-]Error:permissions on /etc/motd are  not configured (Scored) . To Configured it, Please check section 1.7.1.4 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 1.7.1.5 Ensure permissions on /etc/issue are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/issue)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/issue are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/issue are not configured (Scored). To Configured it, Please check section 1.7.1.5 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 1.7.1.6 Ensure permissions on /etc/issue.net are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/issue.net)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/issue.net are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/issue.net are not configured (Scored). To Configured it, Please check section 1.7.1.6 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 1.7.1 Command Line Warning Banners  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 1.8 Ensure updates, patches, and additional security software are installed (Not Scored) *****************"
echo " "
out="$(yum check-update | wc -l)"
if [[ $out == 0 ]]; then
	echo "[+]Pass:updates, patches, and additional security software are installed (Not Scored)"
else
        echo "[-][-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
fi
echo "=================================================================================="
echo "    *************** 2 Services  *****************"
echo "    *************** 2.1 inetd services *****************"
echo " "
echo "*************** 2.1.1 Ensure chargen services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " " 
echo " " 
echo "*************** 2.1.2 Ensure daytime services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.3 Ensure daytime services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.4 Ensure discard services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.5 Ensure time services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.6 Ensure rsh services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.7 Ensure talk services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.8 Ensure telnet services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.9 Ensure tftp services are not enabled (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.1.10 Ensure xinetd is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep xinetd)"
if [ -z "$out" ]; then
        echo "[+]Pass:xinetd is not enabled (Scored) "
else
        echo "[-]Error:xinetd is  enabled (Scored). To disable it,  Please check section 2.1.10 in CIS Benchmark "
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 2.2 Special Purpose Services *****************"
echo " "
echo "*************** 2.1.1 Time Synchronization  *****************"
echo "*************** 2.2.1.1 Ensure time synchronization is in use (Not Scored)  *****************"
out="$(rpm -qa ntp)"
if [[ $out = *"ntp"* ]]; then
         echo "[+]Pass:time synchronization is in use (Not Scored)"
else
        echo "[-]Error:time synchronization is not in  use (Not Scored). To installed  it,  Please check section 2.1.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 2.2.1.2 Ensure ntp is configured (Scored)  *****************"
out="$(grep -E "^(server)" /etc/ntp.conf)"
if [[ $out = *"server"* ]]; then
         echo "[+]Pass:ntp is configured (Scored)"
else
        echo "[-]Error: ntp is not configured (Scored) To configure  it,  Please check section 2.1.1.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 2.2.1.3 Ensure chrony is configured (Scored)  *****************"
echo "[+]Pass: NTP already congfigured.Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " " 
echo "*************** 2.2.1.4 Ensure systemd-timesyncd is configured (Scored)  *****************"
echo "[+]Pass: NTP already congfigured.Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 2.2.2 Ensure X Window System is not installed (Scored)  *****************"
out="$(rpm -qa xorg-x11*)"
if [[ $out = *"xorg-x11"* ]]; then
	echo "[-]Partially Pass-We Can take Exception for this Vulnerability"
        echo "[+]Done"

else
         echo "[+]Pass: X Window System is not installed (Scored)"
fi
echo " "
echo " "
echo "*************** 2.2.3 Ensure Avahi Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep avahi-daemon)"
if [ -z "$out" ]; then
        echo "[+]Pass:Avahi Server is not enabled (Scored) "
else
        echo "[-]Error:Avahi Server is enabled (Scored).To disable it,  Please check section 2.2.3 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.4 Ensure CUPS is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep cups)"
if [ -z "$out" ]; then
        echo "[+]Pass: CUPS is not enabled (Scored) "
else
        echo "[-]Error:CUPS is enabled (Scored).To disable it,  Please check section 2.2.4 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.5 Ensure DHCP server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep dhcp)"
if [ -z "$out" ]; then
        echo "[+]Pass: DHCP Server is not enabled (Scored) "
else
        echo "[-]Error:DHCP Server is enabled (Scored).To disable it,  Please check section 2.2.5 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.6 Ensure LDAP server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep slapd)"
if [ -z "$out" ]; then
        echo "[+]Pass: LDAP Server is not enabled (Scored) "
else
        echo "[-]Error:LDAP Server is enabled (Scored).To disable it,  Please check section 2.2.6 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.7 Ensure NFS and RPC are not enabled (Scored)  *****************"
out="$(chkconfig --list nfs | grep on)"
if [ -z "$out" ]; then
        echo "[+]Pass: NFS is not enabled (Scored) "
else
        echo "[-]Error:NFS is enabled (Scored).To disable it,  Please check section 2.2.7 in CIS Benchmark "
fi
out="$(chkconfig --list rpcbind | grep on)"
if [ -z "$out" ]; then
        echo "[+]Pass: RPC is not enabled (Scored) "
else
        echo "[-]Error:RPC is enabled (Scored)"
	echo "Disabling RPC......................."
        chkconfig rpcbind off
        echo "[+]Done"
	

fi
echo " "
echo " "
echo "*************** 2.2.8 Ensure DNS Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep named)"
if [ -z "$out" ]; then
        echo "[+]Pass: DNS Server is not enabled (Scored) "
else
        echo "[-]Error:DNS Server is enabled (Scored).To disable it,  Please check section 2.2.8 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.9 Ensure FTP Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep vsftpd)"
if [ -z "$out" ]; then
        echo "[+]Pass: FTP Server is not enabled (Scored) "
else
        echo "[-]Error:FTP server is enabled (Scored).To disable it,  Please check section 2.2.9 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.10 Ensure HTTP Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep httpd)"
if [ -z "$out" ]; then
        echo "[+]Pass: HTTP Server is not enabled (Scored) "
else
        echo "[-]Error:HTTP server is enabled (Scored).To disable it,  Please check section 2.2.10 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.11 Ensure IMAP and POP3 server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep dovecot)"
if [ -z "$out" ]; then
        echo "[+]Pass:IMAP and POP3 server is not enabled (Scored)) "
else
        echo "[-]Error:IMAP and POP3 server is  enabled (Scored).To disable it,  Please check section 2.2.11 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.2.12 Ensure Samba is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep smb)"
if [ -z "$out" ]; then
        echo "[+]Pass:Samba is not enabled (Scored)) "
else
        echo "[-]Error:Samba is  enabled (Scored).To disable it,  Please check section 2.2.12 in CIS Benchmark "
fi
echo " "
echo " "
echo "***************  2.2.13 Ensure HTTP Proxy Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep squid)"
if [ -z "$out" ]; then
        echo "[+]Pass:HTTP Proxy Server  is not enabled (Scored)) "
else
        echo "[-]Error:HTTP Proxy Server is enabled (Scored).To disable it,  Please check section 2.2.13 in CIS Benchmark "
fi
echo " "
echo " "
echo "***************  2.2.14 Ensure SNMP Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep snmpd)"
if [ -z "$out" ]; then
        echo "[+]Pass:SNMP Server  is not enabled (Scored)) "
else
        echo "[-]Error:SNMP Server is enabled (Scored).To disable it,  Please check section 2.2.14 in CIS Benchmark "
fi
echo " "
echo " "
echo "***************  2.2.15 Ensure mail transfer agent is configured for local-only mode (Scored)  *****************"
out="$(ss -lntu | grep -E ':25\s' | grep -E -v '\s(127.0.0.1|::1):25\s')"
if [ -z "$out" ]; then
        echo "[+]Pass:mail transfer agent is configured for local-only mode (Scored)) "
else
        echo "[-]Error:mail transfer agent is not configured for local-only mode (Scored).To configured it,  Please check section 2.2.15 in CIS Benchmark "
fi
echo " "
echo " "
echo "***************  2.2.16 Ensure rsync service is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep rsyncd)"
if [ -z "$out" ]; then
        echo "[+]Pass:rsync service is not enabled (Scored) "
else
        echo "[-]Error:rsync service is  enabled (Scored). To Disabled it,  Please check section 2.2.16 in CIS Benchmark "
fi
echo " "
echo " "
echo "***************  2.2.17 Ensure NIS Server is not enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep ypserv)"
if [ -z "$out" ]; then
        echo "[+]Pass:NIS Server is not enabled (Scored) "
else
        echo "[-]Error:NIS Server is  enabled (Scored). To Disabled it,  Please check section 2.2.17 in CIS Benchmark "
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 2.3 Service Clients ****************"
echo " "
echo "*************** 2.3.1 Ensure NIS Client is not installed (Scored)  *****************"
out="$(rpm -q ypbind)"
if [ "$out" == "package ypbind is not installed" ]; then
        echo "[+]Pass:NIS Client is not installed (Scored)"
else
	echo "[-]Error:NIS Client is installed (Scored). To Uninstalled it,  Please check section 2.3.1 in CIS Benchmark "
fi
echo " "
echo " " 
echo "*************** 2.3.2 Ensure rsh client is not installed (Scored)  *****************"
out="$(rpm -q rsh)"
if [ "$out" == "package rsh is not installed" ]; then
        echo "[+]Pass:rsh Client is not installed (Scored)"
else
        echo "[-]Error:rsh Client is installed (Scored). To Uninstalled it,  Please check section 2.3.2 in CIS Benchmark "
fi
echo " "
echo "*************** 2.3.3 Ensure talk client is not installed (Scored)  *****************"
out="$(rpm -q talk)"
if [ "$out" == "package talk is not installed" ]; then
        echo "[+]Pass:talk Client is not installed (Scored)"
else
        echo "[-]Error:talk Client is installed (Scored). To Uninstalled it,  Please check section 2.3.3 in CIS Benchmark "
fi
echo " "
echo " " 
echo "*************** 2.3.4 Ensure telnet client is not installed (Scored)  *****************"
out="$(rpm -q telnet)"
if [ "$out" == "package telnet is not installed" ]; then
        echo "[+]Pass:telnet Client is not installed (Scored)"
else
        echo "[-]Error:telnet Client is installed (Scored). To Uninstalled it,  Please check section 2.3.4 in CIS Benchmark "
fi
echo " "
echo " "
echo "*************** 2.3.5 Ensure LDAP client is not installed (Scored)  *****************"
out="$(rpm -q openldap-clients)"
if [ "$out" == "package openldap-clients is not installed" ]; then
        echo "[+]Pass:LDAP Client is not installed (Scored)"
else
        echo "[-]Error:LDAP Client is installed (Scored). To Uninstalled it,  Please check section 2.3.5 in CIS Benchmark "
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 3 Network Configuration  *****************"
echo "    *************** 3.1 Network Parameters (Host Only)  *****************"
echo " "
echo "    *************** 3.1.1 Ensure IP forwarding is disabled (Scored)  *****************"
out="$(sysctl net.ipv4.ip_forward)";
if [[ $out = "net.ipv4.ip_forward = 0" ]]; then
        echo "[+]Pass: IPV4 forwarding is disabled (Scored)"
else
        echo "[-]Error: IPV4 forwarding is not disabled (Scored). To configured it, Please check section 3.1.1 in CIS Benchmark"
fi
out="$(sysctl net.ipv6.conf.all.forwarding)";
if [[ $out = "net.ipv6.conf.all.forwarding = 0" ]]; then
        echo "[+]Pass: IPV6 forwarding is disabled (Scored)"
else
        echo "[-]Error: IPV6 forwarding is not disabled (Scored). To configured it, Please check section 3.1.1 in CIS Benchmark"
fi

echo " "
echo " "
echo "    *************** 3.1.2 Ensure packet redirect sending is disabled (Scored)  *****************"
out="$(sysctl net.ipv4.conf.all.send_redirects)";
out1="$(sysctl net.ipv4.conf.all.send_redirects)";
if [[ $out = "net.ipv4.conf.all.send_redirects = 0" && $out1 = "net.ipv4.conf.default.send_redirects = 0" ]]; then
        echo "[+]Pass: packet redirect sending is disabled (Scored)"
else
	echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"

fi
echo " "
echo " "
echo "    *************** 3.2 Network Parameters (Host and Router)  *****************"
echo " "
echo "    *************** 3.2.1 Ensure source routed packets are not accepted (Scored)  *****************"
out="$(sysctl net.ipv4.conf.all.accept_source_route)"
out1="$(sysctl net.ipv4.conf.default.accept_source_route)"
if [[ $out = "net.ipv4.conf.all.accept_source_route = 0" && $out1 = "net.ipv4.conf.default.accept_source_route = 0" ]]; then
        echo "[+]Pass: source routed packets are not accepted (Scored)"
else
        echo "[-]Error: source routed packets are accepted (Scored). To disabled it, Please check section 3.2.1 in CIS Benchmark"
fi
echo " " 
echo " " 
echo "    ***************  3.2.2 Ensure ICMP redirects are not accepted (Scored)  *****************"
out="$(sysctl net.ipv4.conf.all.accept_redirects)"
out1="$(sysctl net.ipv4.conf.default.accept_redirects)"
if [[ $out = "net.ipv4.conf.all.accept_redirects = 0" && $out1 = "net.ipv4.conf.default.accept_redirects = 0" ]]; then
        echo "[+]Pass:ICMP redirects are not accepted (Scored)"
else
	echo "Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
fi
echo " " 
echo " " 
echo "    ***************  3.2.3 Ensure secure ICMP redirects are not accepted (Scored)  *****************"
out="$(sysctl net.ipv4.conf.all.secure_redirects)"
out1="$(sysctl net.ipv4.conf.default.secure_redirects)"
if [[ $out = "net.ipv4.conf.all.secure_redirects = 0" && $out1 = "net.ipv4.conf.default.secure_redirects = 0" ]]; then
        echo "[+]Pass:Secure ICMP redirects are not accepted (Scored)"
else
	echo "Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
fi
echo " "
echo " "
echo "    ***************  3.2.4  Ensure suspicious packets are logged (Scored) *****************"
out="$(sysctl net.ipv4.conf.all.log_martians)"
out1="$(sysctl net.ipv4.conf.default.log_martians)"
if [[ $out = "net.ipv4.conf.all.log_martians = 1" && $out1 = "net.ipv4.conf.default.log_martians = 1" ]]; then
        echo "[+]Pass:suspicious packets are logged (Scored)"
else
	echo "[-]Error:suspicious packets are logged (Scored)"
	echo "Fixing the suspicious packets..................."
                echo "net.ipv4.conf.all.log_martians = 1" >> /etc/sysctl.d/*
                echo "net.ipv4.conf.default.log_martians = 1" >> /etc/sysctl.d/*
                sysctl -w net.ipv4.conf.all.log_martians=1
                sysctl -w net.ipv4.conf.default.log_martians=1
		sysctl -w net.ipv4.route.flush=1
                echo "[+]Done"
        
fi
echo " "
echo " "
echo "    ***************  3.2.5 Ensure broadcast ICMP requests are ignored (Scored) *****************"
out="$(sysctl net.ipv4.icmp_echo_ignore_broadcasts)";
if [[ $out = "net.ipv4.icmp_echo_ignore_broadcasts = 1" ]]; then
        echo "[+]Pass: broadcast ICMP requests are ignored (Scored)"
else
        echo "[-]Error: broadcast ICMP requests are ignored (Scored). To configured it, Please check section 3.2.5 in CIS Benchmark"
fi
echo " "
echo " "
echo "    ***************  3.2.6 Ensure bogus ICMP responses are ignored (Scored) *****************"
out="$(sysctl net.ipv4.icmp_ignore_bogus_error_responses)";
if [[ $out = "net.ipv4.icmp_ignore_bogus_error_responses = 1" ]]; then
        echo "[+]Pass: broadcast ICMP requests are ignored (Scored)"
else
        echo "[-]Error: broadcast ICMP requests are ignored (Scored)To configured it, Please check section 3.2.5 in CIS Benchmark"
fi
echo " "
echo " "
echo "    ***************  3.2.7  Ensure Reverse Path Filtering is enabled (Scored)  *****************"
out="$(sysctl net.ipv4.conf.all.rp_filter)"
out1="$(sysctl net.ipv4.conf.default.rp_filter)"
if [[ $out = "net.ipv4.conf.all.rp_filter = 1" && $out1 = "net.ipv4.conf.default.rp_filter = 1" ]]; then
        echo "[+]Pass:Reverse Path Filtering is enabled (Scored)"
else
        echo "[-]Error: Reverse Path Filtering is not enabled (Scored)."
	echo "Enabling the reverse path filtering....................."
                echo "net.ipv4.conf.all.rp_filter = 1" >> /etc/sysctl.d/*
                echo "net.ipv4.conf.default.rp_filter = 1" >> /etc/sysctl.d/*
                sysctl -w net.ipv4.conf.all.rp_filter=1
		sysctl -w net.ipv4.conf.default.rp_filter=1
		sysctl -w net.ipv4.route.flush=1
                echo "[+]Done"
        
fi
echo " "
echo " "
echo "    ***************  3.2.8 Ensure TCP SYN Cookies is enabled (Scored) *****************"
out="$(sysctl net.ipv4.tcp_syncookies)";
if [[ $out = "net.ipv4.tcp_syncookies = 1" ]]; then
        echo "[+]Pass: TCP SYN Cookies is enabled (Scored)"
else
        echo "[-]Error: TCP SYN Cookies is  not enabled (Scored). To configured it, Please check section 3.2.8 in CIS Benchmark"
fi
echo " "
echo " "
echo "    ***************  3.2.9  Ensure IPv6 router advertisements are not accepted (Scored)  *****************"
out="$(sysctl net.ipv6.conf.all.accept_ra)"
out1="$(sysctl net.ipv6.conf.default.accept_ra)"
if [[ $out = "net.ipv6.conf.all.accept_ra = 0" && $out1 = "net.ipv6.conf.default.accept_ra = 0" ]]; then
        echo "[+]Pass:IPv6 router advertisements are not accepted (Scored)"
else
        echo "[-]Error: IPv6 router advertisements are accepted (Scored)."
	echo "Disabling the IPv6 router advertisements...................."
                echo "net.ipv6.conf.all.accept_ra = 0" >> /etc/sysctl.d/*
                echo "net.ipv6.conf.default.accept_ra = 0" >> /etc/sysctl.d/*
                sysctl -w net.ipv6.conf.all.accept_ra=0
		sysctl -w net.ipv6.conf.default.accept_ra=0
		sysctl -w net.ipv6.route.flush=1
                echo "[+]Done"
        
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 3.3 TCP Wrappers  *****************"
echo " "
echo "*************** 3.3.1 Ensure TCP Wrappers is installed (Not Scored)  *****************"
out="$(rpm -qa tcp_wrappers)"
if [[ $out = *"tcp"* ]]; then
         echo "[+]Pass:TCP Wrappers is installed (Not Scored)"
else
        echo "[-]Error:TCP Wrappers is  not installed (Not Scored). To installed  it,  Please check section 3.3.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.3.2 Ensure /etc/hosts.allow is configured (Not Scored)  *****************"

if [[ -f "/etc/hosts.allow" ]]; then
   echo "[+]Pass: /etc/hosts.allow is Present (Not Scored)"
else
   echo "[-]Error: /etc/hosts.allow is not Present (Not Scored). To configured  it,  Please check section 3.3.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.3.3 Ensure /etc/hosts.deny is configured (Not Scored)  *****************"

if [[ -f "/etc/hosts.deny" ]]; then
   echo "[+]Pass: /etc/hosts.deny is Present (Not Scored)"
else
   echo "[-]Error: /etc/hosts.deny is not Present (Not Scored). To configured  it,  Please check section 3.3.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.3.4 Ensure permissions on /etc/hosts.allow are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/hosts.allow)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass: permissions on /etc/hosts.allow are configured (Scored)"
else
        echo "[-]Error:Ensure permissions on /etc/hosts.allow are not configured (Scored). To configured it, Please check section 3.3.4 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.3.5 Ensure permissions on /etc/hosts.deny are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/hosts.deny)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass: permissions on /etc/hosts.deny are configured (Scored)"
else
        echo "[-]Error:Ensure permissions on /etc/hosts.deny are not configured (Scored). To configured it, Please check section 3.3.5 in CIS Benchmark"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 3.4 Uncommon Network Protocols  *****************"
echo " "
echo "*************** 3.4.1 Ensure DCCP is disabled (Scored)  *****************"
out="$(lsmod | grep dccp)"
if [ -z "$out" ]; then
        echo "[+]Pass:DCCP is disabled (Scored)"
else
        echo "[-]Error:DCCP is  not disabled (Scored). To disabled it, Please check Section 3.4.1 in CIS Benchmark"
fi
echo " " 
echo " "
echo "*************** 3.4.2 Ensure SCTP is disabled (Scored)  *****************"
out="$(lsmod | grep sctp)"
if [ -z "$out" ]; then
        echo "[+]Pass:SCTP is disabled (Scored)"
else
        echo "[-]Error:SCTP is  not disabled (Scored). To disabled it, Please check Section 3.4.2 in CIS Benchmark"
fi
echo " " 
echo " "
echo "*************** 3.4.3 Ensure RDS is disabled (Scored)  *****************"
out="$(lsmod | grep rds)"
if [ -z "$out" ]; then
        echo "[+]Pass:RDS is disabled (Scored)"
else
        echo "[-]Error:RDS is  not disabled (Scored). To disabled it, Please check Section 3.4.3 in CIS Benchmark"
fi
echo " " 
echo " "
echo "*************** 3.4.4 Ensure TIPC is disabled (Scored)  *****************"
out="$(lsmod | grep tipc)"
if [ -z "$out" ]; then
        echo "[+]Pass:TIPC is disabled (Scored)"
else
        echo "[-]Error:TIPC is  not disabled (Scored). To disabled it, Please check Section 3.4.4 in CIS Benchmark"
fi
echo " " 
echo " "
echo "=================================================================================="
echo "    *************** 3.5 Firewall Configuration   *****************"
echo " "
echo "*************** 3.5.1 Configure IPv6 ip6tables  *****************"
echo "*************** 3.5.1.1 Ensure IPv6 default deny firewall policy (Scored)  *****************"
out="$(grep "^\s*linux" /boot/grub/grub.conf | grep -v ipv6.disable=1)"
if [ -z "$out" ]; then
        echo "[+]Pass:IPv6 default deny firewall policy (Scored)"
else
        echo "[-]Error:IPv6 default deny firewall policy not in place(Scored).To fix it,  Please  Check section 3.5.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.5.1.2 Ensure IPv6 loopback traffic is configured (Scored)  *****************"
out="$(grep "^\s*linux" /boot/grub/grub.conf | grep -v ipv6.disable=1)"
if [ -z "$out" ]; then
        echo "[+]Pass:IPv6 loopback traffic is configured (Scored)"
else
        echo "[-]Error:IPv6 loopback traffic is not configured (Scored).To fix it,  Please  Check section 3.5.1.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.5.1.3 Ensure IPv6 outbound and established connections are configured (Not Scored)  *****************"
out="$(grep "^\s*linux" /boot/grub/grub.conf | grep -v ipv6.disable=1)"
if [ -z "$out" ]; then
        echo "[+]Pass:IPv6 outbound and established connections are configured (Not Scored)"
else
        echo "[-]Error:IPv6 outbound and established connections are  not configured (Not Scored).To fix it,  Please  Check section 3.5.1.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.5.1.4 Ensure IPv6 firewall rules exist for all open ports (Not Scored)  *****************"
out="$(grep "^\s*linux" /boot/grub/grub.conf | grep -v ipv6.disable=1)"
if [ -z "$out" ]; then
        echo "[+]Pass:IPv6 firewall rules exist for all open ports (Not Scored)"
else
        echo "[-]Error:IPv6 firewall rules are not exist for all open ports (Not Scored).To fix it,  Please  Check section 3.5.1.4 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 3.5.2 Configure IPv4 ip6tables  *****************"
echo "*************** 3.5.2.1 Ensure default deny firewall policy (Scored)  *****************"
iptables -L | grep -i drop; out="$(echo $?)"
if [ "$out" == "0" ]; then
        echo "[+]Pass:default deny firewall  policy is in place (Scored)"
else
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"

fi
echo " "
echo " "

echo "*************** 3.5.2.2  Ensure loopback traffic is configured (Scored) *****************"
iptables -L INPUT -v -n | grep 127.0.0.0; out="$(echo $?)"
iptables -L OUTPUT -v -n | grep -i lo; out1="$(echo $?)"
if [[ $out == "0" && $out1 == "0" ]]; then
        echo "[+]Pass:loopback traffic is configured (Scored)"
else
        echo "[-]Error: loopback traffic is not configured (Scored)"
	echo "Fixing loopback traffic............. "
        iptables -A INPUT -i lo -j ACCEPT
	iptables -A OUTPUT -o lo -j ACCEPT
	iptables -A INPUT -s 127.0.0.0/8 -j DROP
        echo "[+]Done"
        
fi
echo " "
echo " "
echo "*************** 3.5.3 Ensure iptables is installed (Scored)  *****************"
out="$(rpm -q iptables)"
if [[ $out = *"iptables"* ]]; then
         echo "[+]Pass: iptables is installed (Scored)"
else
        echo "[-]Error: iptables is not  installed (Scored). To installed  it,  Please check sect 3.5.33 in CIS Benchmark"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 3.6 Ensure wireless interfaces are disabled (Not Scored)   *****************"
iwconfig >/dev/null 2>&1; out="$(echo $?)"
if [ "$out" == "0" ]; then
        echo "[-]Error:wireless interfaces are congiured on this system.To disabled it Plese check section 3.5"
else
        echo "[+]Pass: wireless interfaces are disabled (Not Scored)"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 3.7 Disable IPv6 (Not Scored)   *****************"
out="$(grep "^\s*linux" /boot/grub/grub.conf | grep -v ipv6.disabled=1)"
if [ -z "$out" ]; then
        echo "[+]Pass:IPv6 is already disabled (Not Scored)"
else
        echo "[-]Error:IPv6 is not disabled.To fix it,  Please  Check section 3.7 in CIS Benchmark"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 4 Logging and Auditing  *****************"
echo "    *************** 4.1 Configure System Accounting (auditd)  *****************"
echo " "
echo "    *************** 4.1.1 Configure Data Retention  *****************"
echo "*************** 4.1.1.1 Ensure audit log storage size is configured (Scored)  *****************"
out="$(grep -iw max_log_file /etc/audit/auditd.conf)"
if [[ $out = "max_log_file = 8" ]]; then
         echo "[+]Pass: audit log storage size is configured (Scored) (Scored)"
else
        echo "[-]Error: audit log storage size is  not configured (Scored). To Configured  it,  Please check sect 4.1.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.1.1.2 Ensure system is disabled when audit logs are full (Scored)  *****************"
out="$(grep -iw space_left_action /etc/audit/auditd.conf)"
out1="$(grep -iw admin_space_left_action /etc/audit/auditd.conf)"
if [[ $out = "space_left_action = email" && $out1 = "admin_space_left_action = halt" ]]; then
        echo "[+]Pass:system is disabled when audit logs are full (Scored)"
else
        echo "[-]Error: system is not disabled when audit logs are full (Scored)"
	echo "Configuring audit logs setting..........................."
                sed -i 's/space_left_action = SYSLOG/space_left_action = email/' /etc/audit/auditd.conf
		sed -i 's/admin_space_left_action = SUSPEND/admin_space_left_action = halt/' /etc/audit/auditd.conf
                echo "[+]Done"
fi
echo " "
echo " "
echo "*************** 4.1.1.3 Ensure audit logs are not automatically deleted (Scored)  *****************"
out="$(grep -iw max_log_file_action /etc/audit/auditd.conf)"
if [[ $out = "max_log_file_action = keep_logs" ]]; then
         echo "[+]Pass: audit logs are not automatically deleted (Scored)"
else
        echo "[-]Error: audit logs are automatically deleted (Scored)."
	echo "Configuring........................................"
                sed -i 's/max_log_file_action = ROTATE/max_log_file_action = keep_logs/' /etc/audit/auditd.conf
		echo "[+]Done"
        
fi
echo " "
echo " "
echo "*************** 4.1.2 Ensure auditd is installed (Scored)  *****************"
out="$(rpm -q audit audit-libs)"
if [[ $out = *"audit"* ]]; then
         echo "[+]Pass: auditd is installed (Scored)"
else
        echo "[-]Error: auditd is not  installed (Scored). To installed  it,  Please check sect 4.1.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.1.3 Ensure auditd service is enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep auditd | grep S | wc -l)"
if [[ $out = "4" ]]; then
         echo "[+]Pass: auditd service is enabled (Scored)"
else
        echo "[-]Error: auditd service is not enabled (Scored). To Configured  it,  Please check sect 4.1.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.1.4 Ensure auditing for processes that start prior to auditd is enabled (Scored)  *****************"
out="$(grep -oh "\w*audit=\w*"  /boot/grub/menu.lst)"
if [[ $out = "audit=1" ]]; then
         echo "[+]Pass: auditing for processes that start prior to auditd is enabled (Scored)"
else
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
fi
echo " "
echo " "
echo "*************** 4.1.5 Ensure events that modify date and time information are collected (Scored)  *****************"
out="$(grep time-change /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:events that modify date and time information are not collected (Scored)."
	echo "Configuring ..........................................."
                echo "-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change" >>/etc/audit/rules.d/audit.rules
		echo "-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change" >>/etc/audit/rules.d/audit.rules
		echo "-a always,exit -F arch=b64 -S clock_settime -k time-change" >>/etc/audit/rules.d/audit.rules
		echo "-a always,exit -F arch=b32 -S clock_settime -k time-change" >>/etc/audit/rules.d/audit.rules
		echo "[+]Done"		
else
        echo "[+]Pass:events that modify date and time information are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.6 Ensure events that modify user/group information are collected (Scored)  *****************"
out="$(grep identity /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:events that modify user/group information are not collected (Scored)."
	echo "Configuring ..........................................."
                echo "-w /etc/group -p wa -k identity" >> /etc/audit/rules.d/audit.rules
		echo "-w /etc/passwd -p wa -k identity" >> /etc/audit/rules.d/audit.rules 
		echo "-w /etc/gshadow -p wa -k identity" >>  /etc/audit/rules.d/audit.rules
		echo "-w /etc/shadow -p wa -k identity " >> /etc/audit/rules.d/audit.rules
		echo "-w /etc/security/opasswd -p wa -k identity" >> /etc/audit/rules.d/audit.rules
		echo "[+]Done"
				
else
        echo "[+]Pass:events that modify user/group information are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.7 Ensure events that modify the system's network environment are collected (Scored)  *****************"
out="$(grep system-locale /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:the system's network environment are not collected (Scored)."
	echo "Configuring.........................................................."
                echo "-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale" >> /etc/audit/rules.d/audit.rules
		echo "-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale" >> /etc/audit/rules.d/audit.rules 
		echo "-w /etc/issue -p wa -k system-locale" >>  /etc/audit/rules.d/audit.rules
		echo "-w /etc/issue.net -p wa -k system-locale" >> /etc/audit/rules.d/audit.rules
		echo "-w /etc/hosts -p wa -k system-locale" >> /etc/audit/rules.d/audit.rules
		echo "-w /etc/sysconfig/network -p wa -k system-locale" >> /etc/audit/rules.d/audit.rules
		echo "[+]Done"
				
else
        echo "[+]Pass:events that modify the system's network environment are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.8 Ensure events that modify the system's Mandatory Access Controls are collected (Scored)  *****************"
out="$(grep MAC-policy /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:system's Mandatory Access Controls are collected (Scored)."
	echo "Configuring.........................................................."
                echo "-w /etc/selinux/ -p wa -k MAC-policy" >> /etc/audit/rules.d/audit.rules
		echo "-w /usr/share/selinux/ -p wa -k MAC-policy" >> /etc/audit/rules.d/audit.rules 
		echo "[+]Pass:events that modify the system's Mandatory Access Controls are collected (Scored)"		
	echo "[+]Done"
else
        echo "[+]Pass:events that modify the system's Mandatory Access Controls are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.9 Ensure login and logout events are collected (Scored)  *****************"
out="$(grep logins /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:login and logout events are not collected (Scored)."
	echo "Configuring................................................."
                echo "-w /var/log/faillog -p wa -k logins" >> /etc/audit/rules.d/audit.rules
		echo "-w /var/log/lastlog -p wa -k logins" >> /etc/audit/rules.d/audit.rules 
		echo "-w /var/log/tallylog -p wa -k logins" >> /etc/audit/rules.d/audit.rules 
	echo "[+]Done"
else
        echo "[+]Pass:login and logout events are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.10 Ensure session initiation information is collected (Scored)  *****************"
out="$(grep sessions /etc/audit/rules.d/audit.rules 2>/dev/null)"
if [ -z "$out" ]; then
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"	

else
        echo "[+]Pass:session initiation information is collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.11 Ensure discretionary access control permission modification events are collected (Scored)  *****************"
out="$(grep perm_mod /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:permission modification events are not collected (Scored)."
	 echo "Configuring.........................................................."
echo "-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules
echo "-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules 
echo "-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules 
echo "-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules
echo "-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules
echo "-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=500 -F auid!=4294967295 -k perm_mod" >> /etc/audit/rules.d/audit.rules
echo "[+]Done"
				
       
else
        echo "[+]Pass:discretionary access control permission modification events are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.12 Ensure unsuccessful unauthorized file access attempts are collected (Scored)  *****************"
out="$(grep access /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error: unauthorized file access attempts are not collected (Scored)."
	 echo "Configuring.........................................................."
                echo "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access" >> /etc/audit/rules.d/audit.rules
				echo "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=500 -F auid!=4294967295 -k access" >> /etc/audit/rules.d/audit.rules 
				echo "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access" >> /etc/audit/rules.d/audit.rules 
				echo "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=500 -F auid!=4294967295 -k access" >> /etc/audit/rules.d/audit.rules	
					
echo "[+]Done"
else
        echo "[+]Pass:unsuccessful unauthorized file access attempts are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.13 Ensure use of privileged commands is collected (Scored)  *****************"
echo "[+]Pass: Not applicable for Amazon Linux AMI.We can ingore this."
echo " "
echo " "
echo "*************** 4.1.14 Ensure successful file system mounts are collected (Scored)  *****************"
out="$(grep mounts /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:file system mounts are not collected (Scored)."
	 echo "Configuring.........................................................."
        echo "-a always,exit -F arch=b64 -S mount -F auid>=500 -F auid!=4294967295 -k mounts" >> /etc/audit/rules.d/audit.rules
	echo "-a always,exit -F arch=b32 -S mount -F auid>=500 -F auid!=4294967295 -k mounts" >> /etc/audit/rules.d/audit.rules 
	 echo "[+]Done"			
else
        echo "[+]Pass:unsuccessful unauthorized file access attempts are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.15 Ensure file deletion events by users are collected (Scored)  *****************"
out="$(grep delete /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:file deletion events by users are not collected (Scored)."
	 echo "Configuring.........................................................."
                echo "-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete" >> /etc/audit/rules.d/audit.rules
				echo "-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=500 -F auid!=4294967295 -k delete" >> /etc/audit/rules.d/audit.rules 
	echo "[+]Done"			
else
        echo "[+]Pass:file deletion events by users are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.16 Ensure changes to system administration scope (sudoers) is collected (Scored)  *****************"
out="$(grep scope /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:changes to system administration scope (sudoers) is collected (Scored)."
	 echo "Configuring.........................................................."
                echo "-w /etc/sudoers -p wa -k scope" >> /etc/audit/rules.d/audit.rules
		echo "-w /etc/sudoers -p wa -k scope" >> /etc/audit/rules.d/audit.rules 
				
		echo "[+]Done"
else
        echo "[+]Pass:changes to system administration scope (sudoers) is collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.17 Ensure system administrator actions (sudolog) are collected (Scored)  *****************"
out="$(grep actions /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:system administrator actions (sudolog) are not collected (Scored)."
	 echo "Configuring.........................................................."
                echo "-w /var/log/sudo.log -p wa -k actions" >> /etc/audit/rules.d/audit.rules
		echo "[+]Done"		
else
        echo "[+]Pass:system administrator actions (sudolog) are collected (Scored)"
fi
echo " " 
echo " " 
echo "*************** 4.1.18 Ensure kernel module loading and unloading is collected (Scored)  *****************"
out="$(grep modules /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:kernel module loading and unloading is not collected (Scored)"
	 echo "Configuring.........................................................."
                echo "-w /sbin/insmod -p x -k modules" >> /etc/audit/rules.d/audit.rules
		echo "-w /sbin/rmmod -p x -k modules" >> /etc/audit/rules.d/audit.rules
		echo "-w /sbin/modprobe -p x -k modules" >> /etc/audit/rules.d/audit.rules
		echo "-a always,exit -F arch=b64 -S init_module -S delete_module -k modules" >> /etc/audit/rules.d/audit.rules
		echo "[+]Done"		
else
        echo "[+]Pass:kernel module loading and unloading is collected (Scored)"
fi
echo " " 
echo " " 

echo "*************** 4.1.19 Ensure the audit configuration is immutable (Scored)  *****************"
out="$(grep modules /etc/audit/rules.d/*.rules 2>/dev/null)"
if [ -z "$out" ]; then
        echo "[-]Error:the audit configuration is not immutable (Scored)."
	 echo "Configuring.........................................................."
                echo "-e 2" >> /etc/audit/rules.d/99-finalize.rules
		echo "[+]Pass:the audit configuration is immutable (Scored)"
else
        echo "[+]Pass:the audit configuration is immutable (Scored)"
fi
echo " " 
echo " " 
echo "=================================================================================="
echo "    *************** 4.2 Configure Logging   *****************"
echo " "
echo "*************** 4.2.1 Configure rsyslog  *****************"
echo "*************** 4.2.1.1 Ensure rsyslog is installed (Scored)  *****************"
out="$(rpm -q rsyslog)"
if [[ $out = *"rsyslog"* ]]; then
         echo "[+]Pass: rsyslog is installed (Scored)"
else
        echo "[-]Error: rsyslog is not  installed (Scored).To installed it,Please check sect 4.2.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.2.1.2 Ensure rsyslog Service is enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep rsyslog | grep S | wc -l)"
if [[ $out = "4" ]]; then
         echo "[+]Pass: rsyslog service is enabled (Scored)"
else
        echo "[-]Error: rsyslog service is not enabled (Scored).To Configured it,Please check sect 4.2.1.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.2.1.3 Ensure logging is configured (Not Scored)  *****************"
ls -ltr /var/log/* | 2>/dev/null;out="$(echo $?)"
if [[ $out = "0" ]]; then
         echo "[+]Pass: logging is configured (Not Scored)"
else
        echo "[-]Error: logging is  not configured (Not Scored).To Configured it,Please check sect 4.2.1.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 4.2.1.4 Ensure rsyslog default file permissions configured (Scored)  *****************"
out="$(grep ^\$FileCreateMode /etc/rsyslog.conf /etc/rsyslog.d/*.conf)"
if [[ $out = "0640" ]]; then
        echo "[+]Pass: rsyslog default file permissions configured (Scored)"
else
	 echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability."
fi
echo " "
echo " "
echo "*************** 4.2.1.5 Ensure rsyslog is configured to send logs to a remote log host (Scored)  *****************"
out="$(grep "^*.*[^I][^I]*@" /etc/rsyslog.conf /etc/rsyslog.d/*.conf)"
if [ -z "$out" ]; then
		echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerabilit."
        
else
       echo "[+]Pass:rsyslog is configured to send logs to a remote log host (Scored)" 
fi
echo " "
echo " "
echo "*************** 4.2.1.6 Ensure remote rsyslog messages are only accepted on designated log hosts. (Not Scored)  *****************"
out="$(grep '$ModLoad imtcp' /etc/rsyslog.conf)";
out1="$(grep '$InputTCPServerRun' /etc/rsyslog.conf)";
if [[ $out = "$ModLoad imtcp" && $out1 = "$InputTCPServerRun 514" ]]; then
        echo "[+]Pass: remote rsyslog messages are only accepted on designated log hosts. (Not Scored)"
else
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerabilit"
	
fi
echo " "
echo " "
echo "*************** 4.2.2 Configure journald  *****************"
echo "*************** 4.2.2.1 Ensure journald is configured to send logs to rsyslog (Scored)  *****************"
echo "[+]Pass:journald file is not present. Not Applicable for Amazon Linux AMI"
echo " " 
echo " " 
echo "*************** 4.2.2.2 Ensure journald is configured to compress large log files (Scored)  *****************"
echo "[+]Pass:journald file is not present. Not Applicable for Amazon Linux AMI"
echo " " 
echo " " 
echo "*************** 4.2.2.3 Ensure journald is configured to write logfiles to persistent disk (Scored)  *****************"
echo "[+]Pass:journald file is not present. Not Applicable for Amazon Linux AMI"
echo " " 
echo " " 
echo "*************** 4.2.3 Ensure permissions on all logfiles are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /var/log)"
if [[ $out = "755 0 0" ]]; then
        echo "[+]Pass:permissions on on all logfiles are configured (Scored)"
else
        echo "[-]Error:permissions on on all logfiles are not configured (Scored)."
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 4.3 Ensure logrotate is configured (Not Scored)   *****************"
out="$(grep 'rotate 4' /etc/logrotate.conf)"
if [[ $out = "rotate 4" ]]; then
        echo "[+]Pass:logrotate is configured (Not Scored)"
else
        echo "[-]Error:logrotate is configured (Not Scored).Please check section 4.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "=================================================================================="
echo "    *************** 5 Access, Authentication and Authorization  *****************"
echo "    *************** 5.1 Configure cron  *****************"
echo " "
echo "    *************** 5.1.1 Ensure cron daemon is enabled (Scored)  *****************"
out="$(ls /etc/rc*.d | grep crond | grep S | wc -l)"
if [[ $out = "4" ]]; then
         echo "[+]Pass: cron service is enabled (Scored)"
else
        echo "[-]Error: cron service is not enabled (Scored).Please check sect 5.1.1 in CIS Benchmark"
fi
echo " "
echo " "
echo "*************** 5.1.2 Ensure permissions on /etc/crontab are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/crontab)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/crontab is  already configured (Scored)"
else
        echo "[-]Error:permissions on /etc/crontab are not configured (Scored)"
	echo "Configuring..................................................."
        chown root:root /etc/crontab
	chmod og-rwx /etc/crontab
	echo "[+]Done"
fi
echo " " 
echo " "
echo "*************** 5.1.3 Ensure permissions on /etc/cron.hourly are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.hourly)"
if [[ $out = "700 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/cron.hourly are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/cron.hourly are not configured (Scored)."
	 echo "Configuring..................................................."
       	chown root:root /etc/cron.hourly
 	chmod og-rwx /etc/cron.hourly
	 echo "[+]Done"		
fi
echo " " 
echo " "
echo "*************** 5.1.4 Ensure permissions on /etc/cron.daily are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.daily)"
if [[ $out = "700 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/cron.daily are configured (Scored)"
else
        echo "[-]Error:permissions on/etc/cron.daily are not configured (Scored)"
	echo "Configuring..................................................."
        chown root:root /etc/cron.daily
	chmod og-rwx /etc/cron.daily
	echo "[+]Done"
fi
echo " " 
echo " "
echo "*************** 5.1.5 Ensure permissions on /etc/cron.weekly are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.weekly)"
if [[ $out = "700 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/cron.weekly are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/cron.weekly are not configured (Scored)."
	 echo "Configuring..................................................."
        chown root:root /etc/cron.weekly
	chmod og-rwx /etc/cron.weekly				
	 echo "[+]Done"
fi
echo " " 
echo " "
echo "*************** 5.1.6 Ensure permissions on /etc/cron.monthly are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.monthly)"
if [[ $out = "700 0 0" ]]; then
        echo "[+]Pass:permissions on/etc/cron.monthly  are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/cron.monthly  are not configured (Scored)."
	echo "Configuring..................................................."
        chown root:root /etc/cron.monthly
        chmod og-rwx /etc/cron.monthly
         echo "[+]Done"

fi
echo " " 
echo " "
echo "*************** 5.1.7 Ensure permissions on /etc/cron.d are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.d)"
if [[ $out = "700 0 0" ]]; then
        echo "[+]Pass:permissions on//etc/cron.d  are configured (Scored)"
else
        echo "[-]Error:permissions on /etc/cron.d are not configured (Scored)."
	echo "Configuring..................................................."
        chown root:root /etc/cron.d
        chmod og-rwx /etc/cron.d
	echo "[+]Done"

fi
echo " " 
echo " "
echo "*************** 5.1.8 Ensure at/cron is restricted to authorized users (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/cron.allow 2>/dev/null)"
out1="$(stat -L -c "%a %u %g" /etc/at.allow 2>/dev/null)"
if [[ -z "$out" && -z "$out1"  ]]; then
        echo "[+]Pass:at/cron is restricted to authorized users (Scored)"
else
        echo "[-]Error:at/cron is not restricted to authorized users (Scored).To configured it, Please check section 5.1.8 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2 SSH Server Configuration  *****************"
echo " "
echo "    *************** 5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/ssh/sshd_config)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/ssh/sshd_config is  already configured (Scored)"
else
        echo "[-]Error:permissions on /etc/ssh/sshd_config are not configured (Scored).To configured it, Please check section 5.2.1 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.2 Ensure permissions on SSH private host key files are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/ssh/ssh_host_ed25519_key)"
out1="$(stat -L -c "%a %u %g" /etc/ssh/ssh_host_dsa_key)"
if [[ $out = "600 0 0"  || $out1 = "600 0 0"   ]]; then
        echo "[+]Pass:permissions on SSH private host key files are configured (Scored)"
else
        echo "[-]Error:permissions on SSH private host key files are not configured (Scored).To configured it, Please check section 5.1.8 in CIS Benchmark"
fi
echo " "
echo " "
echo "    *************** 5.2.3 Ensure permissions on SSH public host key files are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/ssh/ssh_host_ecdsa_key.pub)"
out1="$(stat -L -c "%a %u %g" /etc/ssh/ssh_host_rsa_key.pub)"
if [[ $out = "644 0 0"  && $out1 = "644 0 0"   ]]; then
        echo "[+]Pass:permissions on SSH public host key files are configured (Scored)"
else
        echo "[-]Error:permissions on SSH public host key files are not configured (Scored).To configured it,Please check section 5.1.8 in CIS Benchmark"
fi
echo " "
echo " "
echo "    *************** 5.2.4 Ensure SSH Protocol is set to 2 (Scored)  *****************"
out="$(grep ^Protocol /etc/ssh/sshd_config)"
if [[ $out = "Protocol 2" ]]; then
        echo "[+]Pass:SSH Protocol is set to 2 (Scored)"
else
        echo "[-]Error:SSH Protocol is not set to 2 (Scored)."
	echo "Configuring..................................................."
	echo "Protocol 2" >> /etc/ssh/sshd_config
	/etc/init.d/sshd restart
	echo "[+]Done"
fi
echo " " 
echo " "
echo "    *************** 5.2.5 Ensure SSH LogLevel is appropriate (Scored)  *****************"
out="$(sshd -T | grep loglevel)"
if [[ $out = "loglevel INFO" ]]; then
        echo "[+]Pass:SSH LogLevel is appropriate (Scored)"
else
        echo "[-]Error:SSH LogLevel is not appropriate (Scored).To configured it,Please check section 5.2.5 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.6 Ensure SSH X11 forwarding is disabled (Scored) *****************"
out="$(sshd -T | grep x11forwarding)"
if [[ $out = "x11forwarding yes" ]]; then
        echo "[+]Pass:SSH X11 forwarding is disabled (Scored)"
else
        echo "[-]Error:SSH X11 forwarding is not disabled (Scored).To configured it,Please check section 5.2.6 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.7 Ensure SSH MaxAuthTries is set to 4 or less (Scored) *****************"
out="$(sshd -T | grep maxauthtries)"
if [[ $out = "maxauthtries 6" ]]; then
        echo "[+]Pass:SSH MaxAuthTries is set to 4 or less (Scored)"
else
        echo "[-]Error:SSH MaxAuthTries is not set to 4 or less (Scored).To configured it,Please check section 5.2.7 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.8 Ensure SSH IgnoreRhosts is enabled (Scored) *****************"
out="$(sshd -T | grep ignorerhosts)"
if [[ $out = "ignorerhosts yes" ]]; then
        echo "[+]Pass:SSH IgnoreRhosts is enabled (Scored)"
else
        echo "[-]Error:SSH IgnoreRhosts is not enabled (Scored).To configured it,Please check section 5.2.7 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.9 Ensure SSH HostbasedAuthentication is disabled (Scored) *****************"
out="$(sshd -T | grep hostbasedauthentication)"
if [[ $out = "hostbasedauthentication no" ]]; then
        echo "[+]Pass:SSH HostbasedAuthentication is disabled (Scored)"
else
        echo "[-]Error:SSH HostbasedAuthentication is not disabled (Scored).To configured it,Please check section 5.2.9 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.10 Ensure SSH root login is disabled (Scored) *****************"
out="$(sshd -T | grep permitrootlogin)"
if [[ $out = "PermitRootLogin no" ]]; then
        echo "[+]Pass:SSH root login is disabled (Scored)"
else
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerabilit"
fi
echo " " 
echo " "
echo "    *************** 5.2.11 Ensure SSH PermitEmptyPasswords is disabled (Scored) *****************"
out="$(sshd -T | grep permitemptypasswords)"
if [[ $out = "permitemptypasswords no" ]]; then
        echo "[+]Pass:SSH PermitEmptyPasswords is disabled (Scored)"
else
        echo "[-]Error:SSH PermitEmptyPasswords is not disabled (Scored).To configured it,Please check section 5.2.11 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.12 Ensure SSH PermitUserEnvironment is disabled (Scored) *****************"
out="$(sshd -T | grep permituserenvironment)"
if [[ $out = "permituserenvironment no" ]]; then
        echo "[+]Pass:SSH PermitUserEnvironment is disabled (Scored)"
else
        echo "[-]Error:SSH PermitUserEnvironment is not disabled (Scored).To configured it,Please check section 5.2.12 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.13 Ensure only strong Ciphers are used (Scored) *****************"
out="$(sshd -T | grep -o 3des-cbc)"
if [[ $out = "3des-cbc" ]]; then
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
else
        echo "[+]Pass:only strong Ciphers are used (Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.2.14 Ensure only strong MAC algorithms are used (Scored) *****************"
out="$(sshd -T | grep -o umac-128@openssh.com)"
if [[ $out = "umac-128@openssh.com" ]]; then
        echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability"
else
		echo "[+]Pass:only strong MAC algorithms are used (Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.2.15 Ensure only strong Key Exchange algorithms are used (Scored) *****************"
out="$(sshd -T | grep -o diffie-hellman-group1-sha1)"
if [[ $out = "diffie-hellman-group1-sha1" ]]; then
       		echo "[-]Partially Pass We Can take Exception for this Vulnerability" 
else
		echo "[+]Pass:only strong Key Exchange algorithms are used (Scored)"	
fi
echo " " 
echo " "
echo "    *************** 5.2.16 Ensure SSH Idle Timeout Interval is configured (Scored) *****************"
out="$(sshd -T | grep clientaliveinterval)"
out1="$(sshd -T | grep clientalivecountmax)"
if [[ $out = "clientaliveinterval 300" && $out1 = "clientalivecountmax 0" ]]; then
        echo "[+]Pass:SSH Idle Timeout Interval is configured (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "    *************** 5.2.17 Ensure SSH LoginGraceTime is set to one minute or less (Scored) *****************"
out="$(sshd -T | grep logingracetime)"
if [[ $out = "logingracetime 60" ]]; then
        echo "[+]Pass:SSH LoginGraceTime is set to one minute or less (Scored) "
else
        echo "[-]Error:SSH LoginGraceTime is not set to one minute or less (Scored) "
	echo "Configuring..................................................."
	sed -i 's/#LoginGraceTime 2m/LoginGraceTime 1m/' /etc/ssh/sshd_config
	/etc/init.d/sshd restart
	echo "[+]Done"
fi
echo " " 
echo " "
echo "    *************** 5.2.18 Ensure SSH access is limited (Scored) *****************"
out="$(grep -i allowusers /etc/ssh/sshd_config)"
if [ -z "$out" ]; then
		echo "[-]Partially Pass-Priority Low:We Can take Exception for this Vulnerability" 
        
else
			echo "[+]Pass:SSH access is limited (Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.2.19 Ensure SSH warning banner is configured (Scored) *****************"
out="$(sshd -T | grep banner)"
if [[ $out = "banner /etc/issue.net" ]]; then
        echo "[+]Pass:SSH warning banner is configured (Scored)"
else
        echo "[-]Error:SSH warning banner is not configured (Scored)."
	echo "Configuring..................................................."
	echo "Banner /etc/issue.net" >> /etc/ssh/sshd_config
	/etc/init.d/sshd restart
	echo "[+]Done"
fi
echo " " 
echo " "
echo "    *************** 5.2.20 Ensure SSH PAM is enabled (Scored) *****************"
out="$(sshd -T | grep -i usepam)"
if [[ $out = "usepam yes" ]]; then
        echo "[+]Pass:SSH PAM is enabled (Scored)"
else
        echo "[-]Error:SSH PAM is not enabled (Scored) .To configured it,Please check section 5.2.20 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.2.21 Ensure SSH AllowTcpForwarding is disabled (Scored) *****************"
out="$(sshd -T | grep -i allowtcpforwarding)"
if [[ $out = "allowtcpforwarding no" ]]; then
        echo "[+]Pass:SSH AllowTcpForwarding is disabled (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "    *************** 5.2.22 Ensure SSH MaxStartups is configured (Scored) *****************"
out="$(sshd -T | grep -i maxstartups)"
if [[ $out = "maxstartups 10:30:60" ]]; then
        echo "[+]Pass:SSH MaxStartups is configured (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "    *************** 5.2.23 Ensure SSH MaxSessions is set to 4 or less (Scored) *****************"
out="$(sshd -T | grep -i maxsessions)"
if [[ $out = "maxsessions 4" ]]; then
        echo "[+]Pass:SSH MaxSessions is set to 4 or less (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "    *************** 5.3 Configure PAM *****************"
echo " "
echo "    *************** 5.3.1 Ensure password creation requirements are configured (Scored) *****************"
out="$(cat /etc/pam.d/system-auth | egrep "minlen|dcredit|ucredit|ocredit|icredit")"
if [ -z "$out" ]; then
      		 echo "[-]Partially Pass We Can take Exception for this Vulnerability" 
else
		echo "[+]Pass:password creation requirements are configured (Scored) "
fi
echo " " 
echo " "
echo "    *************** 5.3.2 Ensure lockout for failed password attempts is configured (Not Scored) *****************"
out="$(cat /etc/pam.d/password-auth | egrep "onerr|unlock_time")"
if [ -z "$out" ]; then
        	echo "[-]Partially Partially  We Can take Exception for this Vulnerability"
else
		echo "[+]Pass:lockout for failed password attempts is  configured (Not Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.3.3 Ensure password reuse is limited (Not Scored) *****************"
out="$(cat /etc/pam.d/system-auth | grep -i remember)"
if [ -z "$out" ]; then
       	
		echo "[-]Partially Pass We Can take Exception for this Vulnerability" 
else
		echo "[+]Pass:password reuse is limited (Not Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.3.4 Ensure password hashing algorithm is SHA-512 (Not Scored) *****************"
out="$(grep -o sha512 /etc/pam.d/system-auth)"
if [[ $out = "sha512" ]]; then
		echo "[+]Pass:password hashing algorithm is SHA-512 (Not Scored)"
		
        
else
		echo "[-]Error:password hashing algorithm is not SHA-512 (Not Scored).To configured it,Please check section 5.3.4 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.4 User Accounts and Environment *****************"
echo " "
echo "    *************** 5.4.1 Set Shadow Password Suite Parameters *****************"
echo "*************** 5.4.1.1 Ensure password expiration is 365 days or less (Scored)  *****************"
out="$(grep ^[^#] /etc/login.defs | grep PASS_MAX_DAYS)"
if [[ $out = "PASS_MAX_DAYS   365" ]]; then
        echo "[+]Pass:password expiration is 365 days or less (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "*************** 5.4.1.2 Ensure minimum days between password changes is 7 or more (Scored)  *****************"
out="$(grep ^[^#] /etc/login.defs | grep PASS_MIN_DAYS)"
if [[ $out = "PASS_MIN_DAYS   7" ]]; then
        echo "[+]Pass:minimum days between password changes is 7 or more (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "*************** 5.4.1.3 Ensure password expiration warning days is 7 or more (Scored)  *****************"
out="$(grep ^[^#] /etc/login.defs | grep PASS_WARN_AGE)"
if [[ $out = "PASS_WARN_AGE   7" ]]; then
        echo "[+]Pass:password expiration warning days is 7 or more (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "*************** 5.4.1.4 Ensure inactive password lock is 30 days or less (Scored)  *****************"
out="$(useradd -D | grep INACTIVE)"
if [[ $out = "INACTIVE=35" ]]; then
        echo "[+]Pass:inactive password lock is 30 days or less (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "*************** 5.4.1.5 Ensure all users last password change date is in the past (Scored)  *****************"
out="$(for usr in $(cut -d: -f1 /etc/shadow); do [[ $(chage --list $usr | grep '^Last password change' | cut -d: -f2) > $(date) ]] && echo "$usr :$(chage --list $usr | grep '^Last password change' | cut -d: -f2)"; done)"
if [ -z "$out" ]; then
        echo "[+]Pass:all users last password change date is in the past (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "

echo "    *************** 5.4.2 Ensure system accounts are secured (Scored) *****************"
out="$(awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' && $7!="'"$(which nologin)"'" && $7!="/bin/false") {print}' /etc/passwd)"
if [ -z "$out" ]; then
        echo "[+]Pass:system accounts are secured (Scored)"
else
        echo "[-]Error:system accounts are not secured (Scored).To configured it,Please check section 5.4.2 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.4.3 Ensure default group for the root account is GID 0 (Scored) *****************"
out="$(grep "^root:" /etc/passwd | cut -f4 -d:)"
if [[ $out = "0" ]]; then
        echo "[+]Pass:default group for the root account is GID 0 (Scored)"
else
        echo "[-]Error:default group for the root account is not GID 0 (Scored).To configured it,Please check section 5.4.3 in CIS Benchmark"
fi
echo " " 
echo " "
echo "    *************** 5.4.4 Ensure default user umask is 027 or more restrictive (Scored) *****************"
out="$(grep ^[^#] /etc/bashrc | grep -i 'umask 027')"
out1="$(grep ^[^#] /etc/profile | grep -i 'umask 027')"
if [[ $out = "umask 027" && $out1 = "umask 027" ]]; then
        echo "[+]Pass:default user umask is 027 or more restrictive (Scored)"
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "    *************** 5.4.5 Ensure default user shell timeout is 900 seconds or less (Scored) *****************"
out="$(grep ^[^#] /etc/bashrc | grep -i 'tmout')"
out1="$(grep ^[^#] /etc/profile | grep -i 'tmout')"
if [[ $out = "TMOUT=900" && $out1 = "TMOUT=900" ]]; then
        echo "[+]Pass:default user shell timeout is 900 seconds or less (Scored)"
else
        echo "[-]Error:default user shell timeout is not 900 seconds or less (Scored)."
	echo "Configuring...................................................."
	echo "TMOUT=900" >> /etc/profile
	echo "TMOUT=900" >> /etc/bashrc
fi
echo " " 
echo " "
echo "    *************** 5.5 Ensure root login is restricted to system console (Not Scored) *****************"
out="$(cat /etc/securetty)"
if [ -z "$out" ]; then
		echo "[-]Error:root login is not restricted to system console (Not Scored).To configured it,Please check section 5.5 in CIS Benchmark"      
else
        echo "[+]Pass:root login is restricted to system console (Not Scored)"
fi
echo " " 
echo " "
echo "    *************** 5.6 Ensure access to the su command is restricted (Scored) *****************"
out="$(grep required  /etc/pam.d/su)"
if [[ $out = "auth           required        pam_wheel.so use_uid" ]]; then
		echo "[+]Pass:access to the su command is restricted (Scored)"		    
else
	echo "[-]Partially Pass We Can take Exception for this Vulnerability"
fi
echo " " 
echo " "
echo "=================================================================================="
echo "    *************** 6 System Maintenance  *****************"
echo "    *************** 6.1 System File Permissions *****************"
echo " "
echo "	  *************** 6.1.1 Audit system file permissions (Not Scored)  *****************"
out="$(rpm -V bash)"
if [ -z "$out" ]; then
		echo "[+]Pass:Audit system file permissions is in place(Not Scored)"      
else
		echo "[-]Error:Audit system file permissions not in place(Not Scored).To configured it,Please check section 6.1.1 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.1.2 Ensure permissions on /etc/passwd are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/passwd)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/passwd are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/passwd are not configured (Scored) . To configured it, Please check section 6.1.2 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.3 Ensure permissions on /etc/shadow are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/shadow)"
if [[ $out = "0 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/passwd are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/passwd are not configured (Scored) . To configured it, Please check section 6.1.3 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.4 Ensure permissions on /etc/group are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/group)"
if [[ $out = "644 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/passwd are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/passwd are not configured (Scored) . To configured it, Please check section 6.1.4 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.5 Ensure permissions on /etc/gshadow are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/gshadow)"
if [[ $out = "0 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/passwd are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/passwd are not configured (Scored) . To configured it, Please check section 6.1.5 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.6 Ensure permissions on /etc/passwd- are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/passwd-)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/passwd are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/passwd are not configured (Scored) . To configured it, Please check section 6.1.6 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.7 Ensure permissions on /etc/shadow- are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/shadow-)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/shadow- are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/shadow- are not configured (Scored).To configured it, Please check section 6.1.7 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.8 Ensure permissions on /etc/group- are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/group-)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/group- are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/group- are not configured (Scored).To configured it, Please check section 6.1.8 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.9 Ensure permissions on /etc/gshadow- are configured (Scored)  *****************"
out="$(stat -L -c "%a %u %g" /etc/gshadow-)"
if [[ $out = "600 0 0" ]]; then
        echo "[+]Pass:permissions on /etc/gshadow- are configured (Scored) "
else
        echo "[-]Error:permissions on /etc/gshadow- are not configured (Scored).To configured it, Please check section 6.1.9 in CIS Benchmark"
fi
echo " "
echo " "
echo "	  *************** 6.1.10 Ensure no world writable files exist (Scored)  *****************"
out="$(df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -0002)"
if [ -z "$out" ]; then
		echo "[+]Pass:no world writable files exist (Scored)"      
else
		echo "[-]Error:world writable files are  exist (Scored).To fix it,Please check section 6.1.10 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.1.11 Ensure no unowned files or directories exist (Scored)  *****************"
out="$(df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nouser)"
if [ -z "$out" ]; then
		echo "[+]Pass:no unowned files or directories exist (Scored)"      
else
		echo "[-]Error:unowned files or directories exist (Scored).To fix it,Please check section 6.1.11 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.1.12 Ensure no ungrouped files or directories exist (Scored)  *****************"
out="$(df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -nogroup)"
if [ -z "$out" ]; then
		echo "[+]Pass:no ungrouped files or directories exist (Scored)"      
else
		echo "[-]Error:ungrouped files or directories exist (Scored).To fix it,Please check section 6.1.12 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.1.13 Audit SUID executables (Not Scored)  *****************"
out="$(df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -4000)"
if [ -z "$out" ]; then
		echo "[-]Error:SUID not executables.To fix it,Please check section 6.1.13 in CIS Benchmark"
		      
else
		 echo "[+]Pass:SUID executables (Not Scored)"     
fi
echo " " 
echo " "
echo "	  *************** 6.1.14 Audit SGID executables (Not Scored)  *****************"
out="$(df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -2000)"
if [ -z "$out" ]; then
		echo "[-]Error:SGID not executables.To fix it,Please check section 6.1.13 in CIS Benchmark"
		      
else
		 echo "[+]Pass:SGID executables (Not Scored)"     
fi
echo " " 
echo " "
echo "    *************** 6.2 User and Group Settings *****************"
echo " "
echo "	  *************** 6.2.1 Ensure password fields are not empty (Scored)  *****************"
out="$(awk -F: '($2 == "" ) { print $1 " does not have a password "}' /etc/shadow)"
if [ -z "$out" ]; then
		echo "[+]Pass:password fields are not empty (Scored) "      
else
		echo "[-]Error:password fields are empty (Scored).To fix it,Please check section 6.2.1 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.2 Ensure no legacy "+" entries exist in /etc/passwd (Scored)  *****************"
out="$(grep '^\+:' /etc/passwd)"
if [ -z "$out" ]; then
		echo "[+]Pass:no legacy "+" entries exist in /etc/passwd (Scored)"      
else
		echo "[-]Error:legacy "+" entries exist in /etc/passwd (Scored).To fix it,Please check section 6.2.2 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.3 Ensure no legacy "+" entries exist in /etc/shadow (Scored)  *****************"
out="$(grep '^\+:' /etc/shadow)"
if [ -z "$out" ]; then
		echo "[+]Pass:no legacy "+" entries exist in /etc/shadow (Scored)"      
else
		echo "[-]Error:legacy "+" entries exist in /etc/shadow (Scored).To fix it,Please check section 6.2.3 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.4 Ensure no legacy "+" entries exist in /etc/group (Scored)  *****************"
out="$(grep '^\+:' /etc/group)"
if [ -z "$out" ]; then
		echo "[+]Pass:no legacy "+" entries exist in /etc/group (Scored)"      
else
		echo "[-]Error:legacy "+" entries exist in /etc/group (Scored).To fix it,Please check section 6.2.4 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "    *************** 6.2.5 Ensure root is the only UID 0 account (Scored) *****************"
out="$(awk -F: '($3 == 0) { print $1 }' /etc/passwd)"
if [[ $out = "root" ]]; then
        echo "[+]Pass:root is the only UID 0 account (Scored) "
else
        echo "[-]Error:root is not only the UID 0 account (Scored) .To fix it,Please check section 5.4.3 in CIS Benchmark"
fi
echo " " 
echo " "
echo "	  *************** 6.2.6 Ensure root PATH Integrity (Scored)  *****************"
out="$(sh $dir_loc/pathintegrity.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:root PATH Integrity is in place (Scored)"      
else
		echo "[-]Error:root PATH Integrity is not in place (Scored).To configured it,Please check section 6.1.1 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.7 Ensure all users' home directories exist (Scored)  *****************"
out="$(sh $dir_loc/dircheck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:all users' home directories exist (Scored)"      
else
		echo "[-]Error:all users' home directories exist (Scored).To configured it,Please check section 6.2.7 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.8 Ensure users' home directories permissions are 750 or more restrictive (Scored)  *****************"
out="$(sh $dir_loc/percheck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:users' home directories permissions are 750 or more restrictive (Scored)"      
else
		echo "[-]Error:users' home directories permissions are  not 750 (Scored).To configured it,Please check section 6.2.8 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.9 Ensure users own their home directories (Scored)  *****************"
out="$(sh $dir_loc/ownck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:users own their home directories (Scored)"      
else
		echo "[-]Error:users are not own their home directories (Scored).To configured it,Please check section 6.2.9 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.10 Ensure users' dot files are not group or world writable (Scored)  *****************"
out="$(sh $dir_loc/fileck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:users' dot files are not group or world writable (Scored)"      
else
		echo "[-]Error:users' dot files are group or world writable (Scored).To configured it,Please check section 6.2.10 in CIS Benchmark"      
fi
echo " " 
echo " "
echo " "
echo "	  *************** 6.2.11 Ensure no users have .forward files (Scored)  *****************"
out="$(sh $dir_loc/forwardck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass: no users have .forward files (Scored)"      
else
		echo "[-]Error:users have .forward files (Scored).To configured it,Please check section 6.2.11 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.12 Ensure no users have .netrc files (Scored)  *****************"
out="$(sh $dir_loc/netrcck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:no users have .netrc files (Scored)"      
else
		echo "[-]Error:users have .netrc files (Scored).To fix it,Please check section 6.2.12 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.13 Ensure users' .netrc Files are not group or world accessible (Scored)  *****************"
out="$(sh $dir_loc/wrdck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:users' .netrc Files are not group or world accessible (Scored)"      
else
		echo "[-]Error:users' .netrc Files are group or world accessible (Scored).To configured it,Please check section 6.2.13 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.14 Ensure no users have .rhosts files (Scored)  *****************"
out="$(sh $dir_loc/rhstck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:no users have .rhosts files (Scored)"      
else
		echo "[-]Error:users have .rhosts files (Scored).To fix it,Please check section 6.2.14 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.15 Ensure all groups in /etc/passwd exist in /etc/group (Scored)  *****************"
out="$(sh $dir_loc/pwdck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:all groups in /etc/passwd exist in /etc/group (Scored)"      
else
		echo "[-]Error:all groups in /etc/passwd are not exist in /etc/group (Scored).To fix it,Please check section 6.2.15 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.16 Ensure no duplicate UIDs exist (Scored)  *****************"
out="$(sh $dir_loc/udck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass: no duplicate UIDs exist (Scored)"      
else
		echo "[-]Error:duplicate UIDs exist (Scored).To fix it,Please check section 6.2.16 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.17 Ensure no duplicate GIDs exist (Scored)  *****************"
out="$(sh $dir_loc/gdck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:  no duplicate GIDs exist (Scored)"      
else
		echo "[-]Error:duplicate GIDs exist (Scored).To fix it,Please check section 6.2.17 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.18 Ensure no duplicate user names exist (Scored)  *****************"
out="$(sh $dir_loc/dupusrck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:no duplicate user names exist (Scored) "      
else
		echo "[-]Error:duplicate user names exist (Scored).To fix it,Please check section 6.2.18 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.19 Ensure no duplicate group names exist (Scored)  *****************"
out="$(sh $dir_loc/dupgrpck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:no duplicate group names exist (Scored)"      
else
		echo "[-]Error:duplicate group names exist (Scored).To fix it,Please check section 6.2.19 in CIS Benchmark"      
fi
echo " " 
echo " "
echo "	  *************** 6.2.20 Ensure shadow group is empty (Scored)  *****************"
out="$(sh $dir_loc/shdgrpck.sh)"
if [ -z "$out" ]; then
		echo "[+]Pass:shadow group is empty (Scored)"      
else
		echo "[-]Error:shadow group is not empty (Scored).To fix it,Please check section 6.2.20 in CIS Benchmark"      
echo " " 
echo " "
fi
echo "=================================================================================="
echo "            *************** Audit Completed  *****************                     "
echo "=================================================================================="

